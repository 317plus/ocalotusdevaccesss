
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.ocalotusoriginalsedition.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.ocalotusoriginalsedition.item.LiumShardItem;
import net.mcreator.ocalotusoriginalsedition.item.LiumCrystalItem;
import net.mcreator.ocalotusoriginalsedition.OcalotusOriginalsEditionMod;

public class OcalotusOriginalsEditionModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OcalotusOriginalsEditionMod.MODID);
	public static final RegistryObject<Item> LIUM_SHARD = REGISTRY.register("lium_shard", () -> new LiumShardItem());
	public static final RegistryObject<Item> LIUM_CRYSTAL = REGISTRY.register("lium_crystal", () -> new LiumCrystalItem());
}
